import { Component, OnInit } from '@angular/core';
import { IEmployee } from 'src/app/models/employee';
import { IProject } from 'src/app/models/project';
import { IProjectDay } from 'src/app/models/projectDay';
import { CalendarService } from 'src/app/services/calendar.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { ProjectDayService } from 'src/app/services/project-day.service';
import { ProjectService } from 'src/app/services/project.service';

interface HashTable<T> {
  [key: string]: T;
}

@Component({
  selector: 'app-calendar-body',
  templateUrl: './calendar-body.component.html',
  styleUrls: ['./calendar-body.component.css'],
})
export class CalendarBodyComponent implements OnInit {
  // projectDays: IProjectDay[] = [];
  projectDays: HashTable<IProjectDay> = {};
  employees: IEmployee[] = [];
  calendarWeeks: number[] = [];
  currentProject?: IProject;

  constructor(
    private employeeService: EmployeeService,
    public projectDayService: ProjectDayService,
    public calendarService: CalendarService,
    public projectService: ProjectService
  ) {}

  ngOnInit() {
    this.getEmployees();
    this.getProjectDays();
    this.calendarService.generateCalendarWeeks();
    this.calendarService.generateCalendarDates();
    // console.log(this.projectDays[0].date);

    // for (let e of this.employees) {
    //   this.projectDayService.generateProjectDaysByMonthByEmployeeId(
    //     this.calendarService.getCurrentMonth(),
    //     e.id
    //   );
    // }
  }

  // ngDoCheck(): void {
  //   this.calendarService.generateCalendarWeeks();
  //   this.calendarService.generateCalendarDates();
  // }

  getEmployees() {
    this.employeeService
      .getEmployees()
      .subscribe((employees) => (this.employees = employees));
  }

  getProjectDays() {
    this.projectDayService.getProjectDays().subscribe((projectDays) => {
      for (let pd of projectDays) {
        this.projectDays[pd.date.toString()] = pd;
      }
      console.log(this.projectDays);
    });
  }

  // getProjectDaysByEmployeeId(id: number | undefined) {
  //   return this.projectDays.filter((p) => p.employeeId === id);
  // }

  getProjectById(mainProjectId: number) {
    this.projectService
      .getProjectById(mainProjectId)
      .subscribe((project) => (this.currentProject = project));
  }

  isCurrentDate(date: Date): boolean {
    const currentDate = new Date();
    return (
      date.getFullYear() === currentDate.getFullYear() &&
      date.getMonth() === currentDate.getMonth() &&
      date.getDate() === currentDate.getDate()
    );
  }

  onEmployeeAdded() {
    this.getEmployees();
  }

  // getProjectDay(date: Date, employee: IEmployee): IProjectDay | undefined {
  //   console.log(this.projectDays);
  //   const projectDay = this.projectDays.find(
  //     (pd) =>
  //       new Date(pd.date).getDate() === date.getDate() &&
  //       pd.employeeId === employee.id
  //   );
  //   if (projectDay) {
  //     return Object.assign(projectDay);
  //   }
  //   return undefined;
  // }
}
