import { Component, Input, OnInit } from '@angular/core';
import { Moment } from 'moment';
import { IEmployee } from 'src/app/models/employee';
import { ProjectService } from 'src/app/services/project.service';
import { IProjectDay } from 'src/app/models/projectDay';

@Component({
  selector: 'app-project-day',
  templateUrl: './project-day.component.html',
  styleUrls: ['./project-day.component.css'],
})
export class ProjectDayComponent implements OnInit {
  // @Input() projectDay?: IProjectDay;
  // @Input() date?: Date;
  // @Input() employee?: IEmployee;
  // @Input() project?: IProject;

  @Input() projectDay?: IProjectDay;

  public projectName?: string;
  constructor(private projectService: ProjectService) {}

  ngOnInit(): void {
    this.getProjectName();
  }

  onClick() {}

  getProjectName(): void {
    console.log(this.projectDay);

    if (!this.projectDay) {
      this.projectName = 'free';
    } else {
      this.projectName = 'loading...';
      this.projectService
        .getProjectById(this.projectDay.mainProjectId)
        .subscribe((p) => (this.projectName = p.name));
    }
  }
}
