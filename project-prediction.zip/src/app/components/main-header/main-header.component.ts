import { Component, OnInit } from '@angular/core';
import { ICustomer } from 'src/app/models/customer';
import { IProject } from 'src/app/models/project';
import { CalendarService } from 'src/app/services/calendar.service';
import { CustomerService } from 'src/app/services/customer.service';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-main-header',
  templateUrl: './main-header.component.html',
  styleUrls: ['./main-header.component.css'],
})
export class MainHeaderComponent implements OnInit {
  public customers: ICustomer[] = [];
  public projects: IProject[] = [];
  public currentCustomerId = 1;
  public currentDate?: Date = undefined;

  constructor(
    private customerService: CustomerService,
    private projectService: ProjectService,
    public calendarService: CalendarService
  ) {}

  ngOnInit(): void {
    this.getCustomers();
    this.currentDate = this.calendarService.getCurrentDate();
  }

  getCustomers() {
    this.customerService.getCustomers().subscribe((customers) => {
      this.customers = customers;
      if (customers && customers[0].id) {
        this.getProjects(customers[0].id);
      }
    });
  }

  getProjects(customerId: number) {
    this.projectService
      .getProjects()
      .subscribe(
        (projects) =>
          (this.projects = projects.filter(
            (project) => project.assignedCustomerId === customerId
          ))
      );
  }

  onSelect(event: any) {
    this.getProjects(+event.target.value);
  }

  onCustomerAdded(customer: ICustomer) {
    this.getCustomers();
  }

  onProjectAdded(project: IProject) {
    console.log(project);
    this.getCustomers();
  }

  onPreviousMonth() {
    this.calendarService.decreaseMonth();
    this.calendarService.generateCalendarDates();
    this.calendarService.generateCalendarWeeks();
    this.currentDate = this.calendarService.getCurrentDate();
    console.log(this.currentDate);
    
  }
  
  onNextMonth() {
    this.calendarService.increaseMonth();
    this.calendarService.generateCalendarDates();
    this.calendarService.generateCalendarWeeks();
    this.currentDate = this.calendarService.getCurrentDate();
    console.log(this.currentDate);
  }
}
