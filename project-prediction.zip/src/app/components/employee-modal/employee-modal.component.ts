import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';
import { ProjectDayService } from 'src/app/services/project-day.service';
import { IEmployee } from '../../models/employee';

@Component({
  selector: 'app-employee-modal',
  templateUrl: './employee-modal.component.html',
  styleUrls: ['./employee-modal.component.css'],
})
export class EmployeeModalComponent implements OnInit {
  @Input() employees?: IEmployee[];
  @Output() addedEmployeeData = new EventEmitter<IEmployee>();
  firstName: string = '';
  lastName: string = '';
  abbreviation: string = '';
  color: string = '#fff';
  hourlyRate: number = 0;

  constructor(private employeeService: EmployeeService, private projectDayService: ProjectDayService) {}

  ngOnInit(): void {}

  onSave() {
    const newEmployee = {
      firstName: this.firstName,
      lastName: this.lastName,
      abbreviation: this.abbreviation,
      color: this.color,
      hourlyRate: this.hourlyRate,
    };
    this.employeeService.addEmployee(newEmployee).subscribe((employee) => {
      console.log(employee);
      this.projectDayService.createAndPostProjectDaysForYearForEmployee(employee);
      this.addedEmployeeData.emit(employee);
    });
  
  }
}
