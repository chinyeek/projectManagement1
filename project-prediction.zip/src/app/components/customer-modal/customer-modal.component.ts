import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ICustomer } from 'src/app/models/customer';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-customer-modal',
  templateUrl: './customer-modal.component.html',
  styleUrls: ['./customer-modal.component.css'],
})
export class CustomerModalComponent implements OnInit {
  @Output() addedCustomerData = new EventEmitter<ICustomer>();
  name: string = '';
  abbreviation: string = '';
  color: string = '#fff';

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {}

  onSave() {
    const newCustomer = {
      name: this.name,
      abbreviation: this.abbreviation,
      color: this.color,
    };
    this.customerService
      .addCustomer(newCustomer)
      .subscribe((customer) => this.addedCustomerData.emit(customer));
  }
}
