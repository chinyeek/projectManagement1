import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ICustomer } from 'src/app/models/customer';
import { IProject } from 'src/app/models/project';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-project-modal',
  templateUrl: './project-modal.component.html',
  styleUrls: ['./project-modal.component.css'],
})
export class ProjectModalComponent implements OnInit {
  @Input() customers?: ICustomer[];
  @Output() addedProjectData = new EventEmitter<IProject>();
  name: string = '';
  abbreviation: string = '';
  color: string = '#fff';
  assignedCustomerId = 0;

  constructor(private projectService: ProjectService) {}

  ngOnInit(): void {}

  onSave() {
    const newProject = {
      name: this.name,
      abbreviation: this.abbreviation,
      color: this.color,
      assignedCustomerId: +this.assignedCustomerId,
    };
    this.projectService
      .addProject(newProject)
      .subscribe((project) => this.addedProjectData.emit(project));
  }
}

