import { IEmployee } from "./employee";

export interface ICustomer {

  id?: number;
  name: string;
  abbreviation: string;
  color?: string;
  assignedEmployees?:IEmployee[];
  
}
