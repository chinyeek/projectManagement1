import { ICustomer } from "./customer";

export interface IProject {

  id?: number;
  name: string;
  abbreviation: string;
  color?: string;
  assignedCustomerId?: number

}
