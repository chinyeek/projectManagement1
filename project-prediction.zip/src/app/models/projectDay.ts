export interface IProjectDay {
  id?: number;
  date: Date;
  mainProjectId?: number;
  employeeId: number;
  isFullDay?: boolean;
  optionalProjectId?: number;
}

export class ProjectDay {
  constructor(
    private id: number | undefined = undefined,
    private date: Date,
    private mainProjectId: number | undefined = undefined,
    private employeeId: number,
    private isFullDay: boolean | undefined = undefined,
    private optionalProjectId: number | undefined = undefined
  ) {}
}

// Date
// Main Project Id
// Employee Id
// Customer Id
// isFullDay
// Optional Project Id
