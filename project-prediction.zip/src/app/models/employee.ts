import { IProjectDay } from "./projectDay";

export interface IEmployee {
   id?: number;
   firstName?: string;
   lastName: string;
   abbreviation: string;
   color?: string;
   hourlyRate?: number;
   projectDays?: IProjectDay[]; 
}
