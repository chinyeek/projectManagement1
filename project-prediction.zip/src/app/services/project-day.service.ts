import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IEmployee } from '../models/employee';
import { IProject } from '../models/project';
import { IProjectDay } from '../models/projectDay';
import { CalendarService } from './calendar.service';

@Injectable({
  providedIn: 'root',
})
export class ProjectDayService {
  private projectsUrl = 'api/projectDays';
  private projectDaysByMonth: IProjectDay[] = [];

  constructor(
    private http: HttpClient,
    private calendarService: CalendarService
  ) {}

  getProjectDays(): Observable<IProjectDay[]> {
    return this.http
      .get<IProjectDay[]>(this.projectsUrl)
      .pipe(catchError(this.handleError<any>('getProjectDays')));
  }

  createAndPostProjectDaysForYearForEmployee(employee: IEmployee) {
    const projectDays: IProjectDay[] = [];
    const currentDate = this.calendarService.getCurrentDate();
    let date = new Date(currentDate.getFullYear(), 0, 1);

    while (currentDate.getFullYear() === date.getFullYear()) {
      if (date.getDay() > 0 && date.getDay() < 6) {
        if (employee.id) {
          const projectDay = {
            // date: new Date(`${currentDate.getFullYear()}-${date.getMonth()}-${date.getDate()}`),
            date: new Date(
              currentDate.getFullYear(),
              date.getMonth(),
              date.getDate()
            ),
            employeeId: employee.id,
          };
          projectDays.push(projectDay);
        }
      }
      date = new Date(date.setDate(date.getDate() + 1));
    }

    this.http
      .post<IProjectDay[]>(this.projectsUrl, projectDays)
      .pipe(catchError(this.handleError<any>('getProjectDays')))
      .subscribe((projectDays) => console.log(projectDays));
  }

  // api/projectDays/
  getProjectDaysByMonth(
    month: number,
    employeeId: number | undefined
  ): IProjectDay[] {
    this.getProjectDays().subscribe((pds) => {
      this.projectDaysByMonth = pds.filter((pd) => {
        console.log(pd.date.getMonth());
        return pd.date.getMonth() === month && pd.employeeId === employeeId;
      });
      console.log(month, employeeId, this.projectDaysByMonth);
    });
    return this.projectDaysByMonth;
  }

  // getProjectDaysByMonth() {
  //   return this.projectDaysByMonth;
  // }

  // id: number;
  // date: Date;
  // mainProjectId?: number;
  // employeeId: number;
  // isFullDay: boolean;
  // optionalProjectId?: number;

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      return of(result as T);
    };
  }
}
