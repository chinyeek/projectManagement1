import { Injectable } from '@angular/core';
import { ICustomer } from '../models/customer';
import { IEmployee } from '../models/employee';
import { IProject } from '../models/project';
import { IProjectDay } from '../models/projectDay';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDataService {
  constructor() {}

  createDb() {
    const customers: ICustomer[] = [
      {
        id: 1,
        name: 'Customer 1',
        abbreviation: 'TC',
        color: '#f6b73c',
      },
      {
        id: 2,
        name: 'Customer 2',
        abbreviation: 'TC',
      },
      {
        id: 3,
        name: 'Customer 3',
        abbreviation: 'TC',
        color: '#f6b73c',
      },
    ];

    const projects: IProject[] = [
      {
        id: 1,
        name: 'Project 1',
        abbreviation: 'TC',
        color: '#f6b73c',
        assignedCustomerId: 2,
      },
      {
        id: 2,
        name: 'Project 2',
        abbreviation: 'TC',
        assignedCustomerId: 2,
      },
      {
        id: 3,
        name: 'Project 3',
        abbreviation: 'TC',
        color: '#f6b73c',
        assignedCustomerId: 1,
      },
    ];

    const employees: IEmployee[] = [
      {
        id: 1,
        firstName: 'John',
        lastName: 'Smith',
        abbreviation: 'JS',
        color: '#f6b73c',
        hourlyRate: 12,
      },
      {
        id: 2,
        firstName: 'Mary',
        lastName: 'Jane',
        abbreviation: 'MJ',
        hourlyRate: 15,
      },
      {
        id: 3,
        firstName: 'Tim',
        lastName: 'Byers',
        abbreviation: 'TB',
        color: '#f6b73c',
        hourlyRate: 18,
      },
    ];
    const projectDays: IProjectDay[] = [
      {
        id: 1,
        date: new Date(2021, 6, 11),
        mainProjectId: 1,
        employeeId: 3,
        isFullDay: true,
      },
      {
        id: 2,
        date: new Date(2021, 6, 12),
        mainProjectId: 2,
        employeeId: 3,
        isFullDay: true,
      },
      {
        id: 3,
        date: new Date(2021, 6, 13),
        mainProjectId: 2,
        employeeId: 3,
        isFullDay: true,
      },
    ];
    return { customers, projects, employees, projectDays };
  }

  public genId(entities: any[]): number {
    return entities.length > 0
      ? Math.max(...entities.map((entity) => (entity.id ? entity.id : 0))) + 1
      : 4;
  }
}
