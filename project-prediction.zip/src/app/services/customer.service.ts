import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ICustomer } from '../models/customer';
import { catchError, delay } from 'rxjs/operators';
import { InMemoryDataService } from './in-memory-data.service';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  constructor(private http: HttpClient) {}

  private customersUrl = 'api/customers';

  getCustomers(): Observable<ICustomer[]> {
    return this.http
      .get<ICustomer[]>(this.customersUrl)
      .pipe(catchError(this.handleError<any>('getCustomers')));
  }

  addCustomer(customer: ICustomer): Observable<ICustomer> {
    
    return this.http
      .post<ICustomer>(this.customersUrl, customer)
      .pipe(catchError(this.handleError<any>('addCustomers')));
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // this.loggerService.log(error);
      return of(result as T);
    };
  }
}
