import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root',
})
export class CalendarService {
  constructor() {}

  public currentDate: Date = new Date();

  selectedMoment = moment(this.currentDate);
  calendarWeeks: number[] = [];
  calendarDates: Date[] = [];

  generateCalendarWeeks() {
    this.calendarWeeks = [];
    const startingWeek = this.selectedMoment.isoWeek();
    for (let i = startingWeek; i <= startingWeek + 4; i++) {
      this.calendarWeeks.push(i);
    }
  }

  getCalendarWeeks() {
    return this.calendarWeeks;
  }

  generateCalendarDates() {
    this.calendarDates = [];
    let date = new Date(
      this.currentDate.getFullYear(),
      this.currentDate.getMonth(),
      1
    );
    while (this.currentDate.getMonth() === date.getMonth()) {
      // console.log('getDay ' + date.getDay());
      // console.log('getDate ' + date.getDate());
      if (date.getDay() > 0 && date.getDay() < 6) {
        this.calendarDates.push(new Date(date));
      }
      date = new Date(date.setDate(date.getDate() + 1));
    }
    console.log(this.calendarDates);
  }

  getCalendarDates(): Date[] {
    return this.calendarDates;
  }

  transformNumberWeekdayToString(dayOfWeek: number) {
    return moment().isoWeekday(dayOfWeek);
  }

  decreaseMonth(): void {
    this.currentDate.setMonth(this.currentDate.getMonth() - 1);
  }

  increaseMonth(): void {
    this.currentDate.setMonth(this.currentDate.getMonth() + 1);
  }

  getCurrentMonth(): number {
    console.log('current month:' + this.currentDate.getMonth());
    return this.currentDate.getMonth();
  }

  getCurrentDate(): Date {
    return new Date(this.currentDate);
  }
}
