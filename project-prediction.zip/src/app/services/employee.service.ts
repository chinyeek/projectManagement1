import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IEmployee } from '../models/employee';
import { catchError, delay } from 'rxjs/operators';
import { InMemoryDataService } from './in-memory-data.service';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  constructor(private http: HttpClient) {}

  private employeesUrl = 'api/employees';

  getEmployees(): Observable<IEmployee[]> {
    return this.http
      .get<IEmployee[]>(this.employeesUrl)
      .pipe(catchError(this.handleError<any>('getEmployees')));
  }

  addEmployee(employee: IEmployee): Observable<IEmployee> {
    
    return this.http
      .post<IEmployee>(this.employeesUrl, employee)
      .pipe(catchError(this.handleError<any>('addEmployees')));
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // this.loggerService.log(error);
      return of(result as T);
    };
  }
}
