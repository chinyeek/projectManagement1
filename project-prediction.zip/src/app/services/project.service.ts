import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IProject } from '../models/project';

@Injectable({
  providedIn: 'root',
})
export class ProjectService {
  constructor(private http: HttpClient) {}

  private projectsUrl = 'api/projects';

  getProjects(): Observable<IProject[]> {
    return this.http
      .get<IProject[]>(this.projectsUrl)
      .pipe(catchError(this.handleError<any>('getProjects')));
  }

  getProjectById(id: number | undefined): Observable<IProject> {
    return this.http
      .get<IProject>(this.projectsUrl + '/' + id)
      .pipe(catchError(this.handleError<any>('getProjectById')));
  }

  addProject(project: IProject): Observable<IProject> {
    return this.http
      .post<IProject>(this.projectsUrl, project)
      .pipe(catchError(this.handleError<any>('addProjects')));
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // this.loggerService.log(error);
      return of(result as T);
    };
  }
}
