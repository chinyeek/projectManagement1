import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { MainHeaderComponent } from './components/main-header/main-header.component';
import { EmployeeModalComponent } from './components/employee-modal/employee-modal.component';
import { CustomerModalComponent } from './components/customer-modal/customer-modal.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './services/in-memory-data.service';
import { ProjectModalComponent } from './components/project-modal/project-modal.component';
import { CalendarBodyComponent } from './components/calendar-body/calendar-body.component';
import { ProjectDayComponent } from './components/project-day/project-day.component';

@NgModule({
  declarations: [
    AppComponent,
    MainHeaderComponent,
    EmployeeModalComponent,
    CustomerModalComponent,
    ProjectModalComponent,
    CalendarBodyComponent,
    ProjectDayComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(InMemoryDataService, {
      dataEncapsulation: false,
    }),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
